package com.Dashboard.DashboardApplication.Exceptions;

public class AllExceptions extends Exception{
	public AllExceptions(String message) {
		super(message);
	}

}
